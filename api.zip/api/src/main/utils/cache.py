import json
import threading
import datetime
from typing import Union



def get_cache_list(**kwargs) -> str:
    """ Get the global conversation cache instance """
    tool_call_caches: dict[str, str] = kwargs.get("tool_call_caches", {})
    if tool_call_caches:
        return json.dumps(list(tool_call_caches.keys()), default=str, ensure_ascii=False)  # datetime 직렬화 지원
    else:
        return "caches is empty"

def get_cache_data(tool_call_cache_id: str, **kwargs) -> str:  # 함수명 오타 수정
    """ Get a specific cache data by name """
    tool_call_caches: dict[str, str] = kwargs.get("tool_call_caches", {})
    if tool_call_caches and tool_call_cache_id in tool_call_caches:
        return json.dumps(tool_call_caches[tool_call_cache_id], default=str, ensure_ascii=False)
    else:
        return f"Cache '{tool_call_cache_id}' not found"